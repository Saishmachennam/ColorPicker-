let bg = document.getElementById("bgCon");
let colorName = document.getElementById("color");

function button1() {
    bg.style.backgroundColor = "#e0e0e0";
    colorName.textContent = "#e0e0e0";
    colorName.style.color = "#e0e0e0";
}

function button2() {
    bg.style.backgroundColor = "#6fcf97";
    colorName.textContent = "#6fcf97";
    colorName.style.color = "#6fcf97";
}

function button3() {
    bg.style.backgroundColor = "#56ccf2";
    colorName.textContent = "#56ccf2";
    colorName.style.color = "#56ccf2";
}

function button4() {
    bg.style.backgroundColor = "#bb6bd9";
    colorName.textContent = "#bb6bd9";
    colorName.style.color = "#bb6bd9";
}